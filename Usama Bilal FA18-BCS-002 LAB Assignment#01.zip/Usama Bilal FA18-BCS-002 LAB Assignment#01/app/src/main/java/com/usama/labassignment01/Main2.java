package com.usama.labassignment01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2 extends AppCompatActivity {

    static int create2=0,
            start2=0,
            restart2=0,
            resume2=0;

    TextView crt2,
            strt2,
            rsm2,
            rstrt2;
    Button btn2ndActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Log.i("key","onCreate is called");
        create2++;
        crt2=findViewById(R.id.crt2);
        strt2=findViewById(R.id.strt2);
        rstrt2=findViewById(R.id.rstrt2);
        rsm2=findViewById(R.id.rsm2);
        btn2ndActivity=findViewById(R.id.btn2ndActivity);
        crt2.setText("onCreate is called: "+create2);
        strt2.setText("onStart is called: "+start2);
        rsm2.setText("onResume is called: "+resume2);
        rstrt2.setText("onRestart is called: "+restart2);

        btn2ndActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Main2.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    protected void onStart(){
        super.onStart();
        Log.i("key","onStart is called");
        start2++;
        strt2.setText("onStart is called: "+start2);
    }

    protected void onRestart(){
        super.onRestart();
        Log.i("key","onRestart is called");
        restart2++;
        rstrt2.setText("onRestart is called: "+restart2);
    }

    protected void onResume(){
        super.onResume();
        Log.i("key","onResume is called");
        resume2++;
        rsm2.setText("onResume is called: "+resume2);
    }

    protected void onPause(){
        super.onPause();
        Log.i("key","onPause is called");
    }

    protected void onStop(){
        super.onStop();
        Log.i("key","onStop is called");
    }
    protected void onDestroy(){
        super.onDestroy();
        Log.i("key","onDestroy is called");
    }
}