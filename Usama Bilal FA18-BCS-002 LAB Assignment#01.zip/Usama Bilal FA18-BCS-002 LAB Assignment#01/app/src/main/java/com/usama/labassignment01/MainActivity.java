package com.usama.labassignment01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    static int create1 = 0,
            start1 = 0,
            restart1 = 0,
            resume1 = 0;

    TextView crt1,
            strt1,
            rsm1,
            rstrt1;
    Button btn1stActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("key", "onCreate is called");
        create1++;
        crt1 = findViewById(R.id.crt1);
        strt1 = findViewById(R.id.strt1);
        rstrt1 = findViewById(R.id.rstrt1);
        rsm1 = findViewById(R.id.rsm1);
        btn1stActivity = findViewById(R.id.btn1stActivity);
        crt1.setText("onCreate called: " + create1);
        strt1.setText("onStart called: " + start1);
        rsm1.setText("onResume called: " + resume1);
        rstrt1.setText("onRestart called: " + restart1);

        btn1stActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2.class);
                startActivity(intent);
            }
        });
    }

    protected void onStart() {
        super.onStart();
        Log.i("key", "onStart is called");
        start1++;
        strt1.setText("onStart is called: " + start1);
    }

    protected void onRestart() {
        super.onRestart();
        Log.i("key", "onRestart is called");
        restart1++;
        rstrt1.setText("onRestart is called: " + restart1);
    }

    protected void onResume() {
        super.onResume();
        Log.i("key", "onResume is called");
        resume1++;
        rsm1.setText("onResume is called: " + resume1);
    }

    protected void onPause() {
        super.onPause();
        Log.i("key", "onPause is called");
    }

    protected void onStop() {
        super.onStop();
        Log.i("key", "onStop is called");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.i("key", "onDestroy is called");
    }
}