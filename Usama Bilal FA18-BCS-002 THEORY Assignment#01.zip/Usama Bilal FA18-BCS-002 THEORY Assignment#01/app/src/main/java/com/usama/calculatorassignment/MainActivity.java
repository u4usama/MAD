package com.usama.calculatorassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText fstInpt;
    private EditText sndInpt;
    private TextView oput;
    private TextView TvList;
    private Button calBtn;
    Spinner spinner;
    private int a=0;
    private int b=0;
    ArrayList<String> arList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
        arList=new ArrayList<>();
        arList.add("Select Operation:");
        arList.add("Add");
        arList.add("Subtract");
        arList.add("Multiply");
        arList.add("Divide");
        ArrayAdapter adapter=new ArrayAdapter(MainActivity.this,R.layout.main2,R.id.TvList,arList);
        spinner.setAdapter(adapter);
        calBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(fstInpt.getText().toString());
                b=Integer.parseInt(sndInpt.getText().toString());
                if(spinner.getSelectedItem().toString() == "Add"){
                    oput.setText("Sum : "+String.valueOf(a+b));
                }
                else if(spinner.getSelectedItem().toString() == "Subtract"){
                    oput.setText(String.valueOf(a-b));
                }
                else if(spinner.getSelectedItem().toString() == "Multiply"){
                    oput.setText(String.valueOf(a*b));
                }
                else if(spinner.getSelectedItem().toString() == "Divide"){
                    if(b == 0){
                        Toast.makeText(MainActivity.this,"Dividing a number with zero",Toast.LENGTH_LONG).show();
                    }
                    else{
                        oput.setText(String.valueOf(a/b)+"    R: "+String.valueOf(a%b));
                    }
                }
                else{
                    Toast.makeText(MainActivity.this,"Invalid",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    private void findView(){
        fstInpt=findViewById(R.id.etNumber1);
        sndInpt=findViewById(R.id.etNumber2);
        spinner=findViewById(R.id.spinner);
        oput=findViewById(R.id.tvOpt);
        calBtn=findViewById(R.id.calbutton);
    }
}
